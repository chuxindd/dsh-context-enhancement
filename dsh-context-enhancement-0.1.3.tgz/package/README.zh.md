# dsh-context-enhancement

面向 **DeepSeek Harness v0.1.2-rc.1** 的上下文增强能力，以**自包含、单包
Profile Bundle** 形式发布。

该 Bundle 为一个 DSH Profile 增加两条独立能力：

1. **持久化 per-Session task state** —— 后台辅助 LLM 为每个 Session 维护权威的、
   存储后端的“任务状态”（facts、decisions、constraints、risks、evidence、
   TODO references、continuation），注入模型运行时上下文；重启后直接恢复，
   无需模型调用。
2. **区域感知分层压缩** —— 官方 compaction 后端的替代实现：保留近期工作上下文
   的高保真，先确定性缩减旧工具输出，重新计量，然后才对更早历史做语义压缩。

## 这是什么

一个独立 GitHub 仓库，其根 package 同时是：

- 一个 npm package（`dsh-context-enhancement`，v0.1.3，ESM），并且
- 一个 DSH Profile Bundle，其 `dsh.bundle.patch` 指向已提交的
  `cordis.patch.yml`，可从固定 GitHub tag 一步安装。

## 功能

| 导出 subpath           | 职责 |
| ---------------------- | ---- |
| `./task-state`         | 只读持久 task-state Service Definition（`ctx.taskState`）与持久 schema |
| `./task-state-basic`   | 持久 provider：独占 `context_enhancement_task_state` storage domain、调度、辅助调用、校验、提交、审计 |
| `./task-state-prompt`  | `systemPrompt` consumer，渲染已提交的 task-state 快照 |
| `./compaction-basic`   | 官方 compaction 后端的区域感知替代实现（`ctx.compaction`） |
| `./tool-result-pruner` | 区域感知、可回放的 tool-result 裁剪服务 |

### 透明性

- **Task-state 审计是 storage-domain 审计表**，不是 Session 事件。
  `dsh-context-enhancement` 不声明任何 `SessionEventMap` 成员，因此卸载
  Bundle 后，旧 Session 日志仍可被 rc.1 代码完整读取。每条审计行记录 request
  id、base stable 的 revision/cursor、included 序列、route/schema/truncation/
  system，成功时含完整 raw output —— 无需修改官方 `llm-replay` 包即可重建
  辅助调用。
- **`sourceCursor` 语义。** 已提交 stable 记录被折叠的最后一个 eligible
  Session 事件序号。重启后，cursor 之后的 eligible 事件稍后在后台处理。
- **已提交结果是权威的。** 重启直接从存储加载已提交 stable —— 无模型调用、
  无历史重建、不重放未完成更新。
- **Compaction 保留官方事务模型。** surface replacement、source references、
  `compaction/start`→summary→`compaction/end` 括弧、持久化与重启恢复均不变；
  只有“选什么、何时压”是分层的。

## 配置

### `task-state-basic` 主机行（全部显式、必填）

Bundle patch 以如下配置插入主机平面 provider。可在 profile/home patch 层覆盖
任一字段（patch 会整体替换该行的 `config`）：

| 字段 | patch 默认值 | 含义 |
| --- | --- | --- |
| `provider` / `model` | `deepseek-official` / `deepseek-v4-flash` | 每次 collect-and-merge 请求的辅助路由 |
| `minEvents` | `20` | 自提交 cursor 以来自动触发 batch 的 eligible 事件数 |
| `maxEvents` | `200` | 单 batch 最多折叠的 eligible 事件数 |
| `maxInputBytes` | `60000` | 单次框架化投影的 UTF-8 字节预算 |
| `maxOutputTokens` | `4000` | 单次辅助请求的生成上限 |
| `timeoutMs` | `120000` | 请求端到端截止时间 |
| `maxInfraRetries` | `2` | 瞬时失败后的额外尝试（确定性失败不重试） |
| `maxEntriesPerKind` | `50` | 每个 stable 中 facts/decisions/constraints/risks 上限 |
| `maxEntryBytes` | `4000` | 单条目 UTF-8 字节上限 |
| `maxListItems` | `40` | 单个列表字段条数上限 |

### `task-state-prompt` preset 行

`maxBytes`（出厂 preset 为 `8000`）限制单个快照的 UTF-8 字节。provider 与
prompt consumer 相互独立：没有 provider 时 consumer 渲染空内容，preset 仍可
挂载。

### Compaction preset 行

`contextual` preset 把官方 compaction 行替换为本 Bundle 的
`compaction-basic` 与 `tool-result-pruner`，保留官方 rc.1 配置词汇
（`thresholdRatio`、`retainRatio`/`retainTokens`、
`summarizationProvider`/`summarizationModel`、`maxTokens`、
`compactionRetries`、`maxOverflowRetries`、`modelPolicies`、`auto`），另加
pruner 的实验性 `hardLimitChars`。`command-compact` 保持官方。

## 安装

本 Bundle 面向 **web profile**（`dsh --profile web`）：web profile 组合
`agent-presets` roster 行，使随附的 `contextual` preset 可选并可设为默认。

```sh
# 安装固定不可变 tag：
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.3'
# 然后重启 Profile：
dsh --profile web
```

> `<owner>` 是占位：本仓库尚未发布 GitHub release，因此上面的命令是模板而非
> 真实 URL。这里没有任何内容已发布。`package.json` 故意不写 `repository.url`。

启动后，新 web session 默认组合 **contextual** preset：完整 `standard`
级别能力，外加任务状态记忆与长对话整理能力。会话标题右侧会出现
**增强功能**，展开后可查看四项已启用的会话能力及其触发次数；详细记录仍可在当前会话的轨迹中查看。
`standard`、
`minimal`、`ptc`、`cordis` 仍可选；你在 `$DSH_HOME/.agent-presets` 下自建的
preset 仍可被发现。

## 桌面版兼容安装

桌面版启动时会重建 `agent-presets` 的 discovery 根目录，不会自动读取第三方 Bundle 内的 `presets/`。安装 Bundle 后，在本仓库目录执行一次：

```powershell
pnpm install:desktop-preset
```

如果当前安装包不在本仓库目录，可设置 preset 源目录：

```powershell
$env:DSH_CONTEXT_ENHANCEMENT_PRESET_ROOT = 'C:\\path\\to\\dsh-context-enhancement\\presets\\contextual'
pnpm install:desktop-preset
```

脚本默认写入：

```text
%DSH_HOME%\\.agent-presets\\contextual
```

已有同名 preset 时脚本会拒绝覆盖；确认需要替换时才使用 `-- --force`。

## 验证顶栏效果

1. 启动 web profile，并打开一个默认的 `contextual` 会话。
2. 在会话标题右侧点击 **增强功能**。
3. 确认面板包含四个独立条目；每项显示“已启用”，尚未发生时显示“本会话尚未触发”。
4. 发送一条普通消息后再次展开面板；相关能力会显示本会话的触发次数。
5. 使用足够多的工具调用或执行长对话整理；对应条目会分别更新触发次数。
6. 打开“轨迹”查看详细记录。

隔离安装和发布检查可直接运行：

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm run release:check
node scripts/verify-profile-install.mjs .\\dsh-context-enhancement-0.1.3.tgz
```

## 新 profile / 无 agent-presets 行的行为

- **新 web profile。** `dsh plugin add` 必要时创建 profile、把 Bundle 加入
  `dsh.profile.bundles`，并在（重启后）应用本 Bundle patch：主机
  `task-state-basic` 行挂载，`agent-presets` 的默认值指向 `contextual`。
- **没有 `agent-presets` 行的 profile**（例如自定义 profile 或未挂载 roster
  的 headless 风格组合）：本 Bundle 的 `agent-presets` patch 会被 Loader 警告
  跳过，只有主机 `task-state-basic` 插入生效。该 profile 的 session 上
  provider 仍工作；因为没有 roster 可改，不会改任何 preset 默认值。

## 升级、回滚、卸载

Profile 插件成员在一次运行期间冻结——任何变更后都要重启。

```sh
# 升级到更新的 tag（显式改写 spec 以避免漂移）：
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.3'
# 回滚到上一个 tag：
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.3'
# 卸载：
dsh plugin --profile web remove dsh-context-enhancement
```

每次变更后重启 profile。卸载会：

- 移除 Bundle 层（`dsh-context-enhancement` 离开 `dsh.profile.bundles`），因此
  下次启动时主机 `task-state-basic` 行与 `agent-presets` 默认覆盖消失；
- **保留存储**：已提交 task-state 记录、审计表与普通 Session 日志原样保留，
  provider 只是不再发布 `ctx.taskState`；
- 恢复官方组合：因为 patch 从不禁用官方主机行，`standard` 的官方 compaction
  行原样回归。

## 存储：保留与清理

所有持久状态位于 DSH home 之下：

- Task state：`$DSH_HOME/storages/context_enhancement_task_state.json`
  （single-layout storage-domain unit，含 `sessions` 与 `audit` 表）。域名刻意
  取 `context_enhancement_task_state`，避免与格式不同的上游域冲突。
- Sessions：不变（`$DSH_HOME/sessions`）。

provider **从不删除**其中介质。要清除 task-state 记录，请停止 profile 后删除
该域文件；provider 会把真正缺失的域当作首次状态。损坏或不兼容的域保持不变：
provider 大声禁用，普通 Session 照常继续。

## 环境要求

- Node `^22.19.0 || >=24.0.0`
- pnpm `11.7.0`（仓库 `packageManager`）
- 与精确 peer pin 兼容的 DSH v0.1.2-rc.1 部署（`@deepseek-ai/dsh-*` 精确
  `0.1.2-rc.1`、`@deepseek-ai/cordis` 精确 `4.0.2`、`@deepseek-ai/schemastery`
  精确 `3.18.2`）。Bundle 同时把这些 rc.1 package 声明为 runtime dependency，
  让 GitHub 安装携带 Loader 所需的依赖闭包；`zod@4.4.3` 为普通 dependency。

## 仓库命令

```sh
pnpm install          # 安装 dev 工具链（allowlist 在 pnpm-workspace.yaml）
pnpm run build        # tsc src -> lib/types，再 tsdown -> 每个入口 lib/*.js
pnpm run typecheck    # 严格类型检查 src 与 tests
pnpm run test         # vitest run
pnpm run release:check   # 打 tag 前的机械检查（依赖、exports、pack 内容）
```

仓库没有 `prepare`/`postinstall` 脚本，也不计划加入：release tag 提交构建产物
（`lib/` 已提交），GitHub 安装无需运行构建脚本。

## rc.1 兼容限制

- 固定 DeepSeek Harness **v0.1.2-rc.1**。升级 DSH 需重新验证并发布新 Bundle
  tag；peer 从不投机放宽。
- 已发布 rc.1 `@deepseek-ai/dsh-compaction` 不导出 Card5/6 leaf
  （`toolSegments`、`selection-guard`）；这些在 `src/internal/` 下本地复制并
  带 provenance。运行时绝不导入 `@deepseek-ai/dsh-*` 的 `src/*` subpath。
- rc.1 的 `GenerateOptions.purpose` 是闭合的 `'compaction' | 'session-title'`
  联合；task-state 辅助调用自行声明目的类型并在流边界转换一次。
- Task-state 审计采用 storage-domain 审计表而非 Session 事件（见透明性），
  绝不写入 rc.1 `task-state/*` Session 事件。

## 目录布局

```text
package.json            root package + dsh.bundle.patch 清单
cordis.patch.yml        bundle patch（主机 task-state-basic + web agent-presets）
src/                    TypeScript 源码（入口模块 + 内部移植）
  task-state.ts           contract：Service Definition + 持久 schema + 审计
  task-state-basic.ts     持久 provider（域、worker、校验）
  task-state-prompt.ts    systemPrompt consumer
  compaction-basic.ts     区域感知 compaction 替代实现
  tool-result-pruner.ts   区域感知裁剪服务
lib/                    已提交的构建产物（tsc types + tsdown 入口）
presets/contextual/     随附 agent preset（rc.1 standard 副本 + 增量）
tests/                  vitest 规格（单测、真实组合、keyless 场景）
scripts/release-check.mjs   打 tag 前机械门禁
CHANGELOG.md            变更记录（0.1.2-unreleased）
THIRD_PARTY_NOTICES.md  DSH MIT 来源声明
README.md / README.zh.md
```

## License

MIT。部分内容改编自 DeepSeek Harness（MIT）——见 `THIRD_PARTY_NOTICES.md`。
