# dsh-context-enhancement

Context-enhancement capabilities for **DeepSeek Harness v0.1.2-rc.1**, shipped
as a self-contained, single-package **Profile Bundle**.

This bundle adds two independent capabilities to a DSH profile:

1. **Durable per-session task state** — a background auxiliary LLM maintains an
   authoritative, storage-backed "task state" (facts, decisions, constraints,
   risks, evidence, TODO references, continuation) for each Session, injected
   into the model's runtime context. It restores directly after restart with no
   model call.
2. **Region-aware layered compaction** — a replacement for the official
   compaction backend that keeps the recent working context at high fidelity,
   deterministically reduces older tool outputs first, remeasures, and only
   then runs semantic compaction of older history.

## What this repository is

A standalone GitHub repository whose root package is simultaneously:

- one npm package (`dsh-context-enhancement`, v0.1.1, ESM), and
- a DSH Profile Bundle whose `dsh.bundle.patch` points at a committed
  `cordis.patch.yml`, installable in one step from a pinned GitHub tag.

## Non-goals

This project is **not** the DeepSeek Harness Web GUI and does not target the
DSH web/desktop application as an app surface. It is a backend capability
bundle only: no UI slots, no client bundle, no browser-facing surface. The
DeepSeek Harness Web GUI is unrelated to this repository.

## Features

| Export subpath        | Role |
| --------------------- | ---- |
| `./task-state`        | Read-only durable task-state Service Definition (`ctx.taskState`) and durable schemas |
| `./task-state-basic`  | Durable provider: owns the `context_enhancement_task_state` storage domain, scheduling, auxiliary calls, validation, commits, audit |
| `./task-state-prompt` | `systemPrompt` consumer rendering the committed task-state snapshot |
| `./compaction-basic`  | Region-aware replacement for the official compaction backend (`ctx.compaction`) |
| `./tool-result-pruner`| Region-aware replay-safe tool-result pruning service |

### Transparency

- **Task-state audit is a storage-domain audit table**, never Session events.
  `dsh-context-enhancement` declares no `SessionEventMap` members, so
  uninstalling the bundle leaves old Session logs fully readable by rc.1 code.
  Each audit row records the request id, base stable revision/cursor, included
  sequences, route/schema/truncation/system, and — on success — complete raw
  output, so the auxiliary call is reconstructable without modifying the
  official `llm-replay` package.
- **`sourceCursor` semantics.** A committed stable records the last eligible
  Session event sequence folded. After restart, eligible events after the
  cursor are processed later in the background.
- **Committed results are authoritative.** Restart loads the committed stable
  directly from storage — no model call, no history fold, no replay of an
  unfinished update.
- **Compaction keeps the official transaction model.** Surface replacement,
  source references, `compaction/start`→summary→`compaction/end` bracketing,
  persistence, and restart recovery are unchanged; only what is selected and
  when is layered.

## Configuration

### The `task-state-basic` host row (explicit, required)

The bundle patch inserts the host-plane provider with this configuration.
Override any field in your profile/home patch layer (a patch replaces the
whole row `config`):

| Field | Default in patch | Meaning |
| --- | --- | --- |
| `provider` / `model` | `deepseek-official` / `deepseek-v4-flash` | Auxiliary route for every collect-and-merge request |
| `minEvents` | `20` | Eligible events since the committed cursor that automatically start a batch |
| `maxEvents` | `200` | Maximum eligible events folded into one batch |
| `maxInputBytes` | `60000` | UTF-8 byte budget of one framed projection |
| `maxOutputTokens` | `4000` | Generation cap of one auxiliary request |
| `timeoutMs` | `120000` | End-to-end request deadline |
| `maxInfraRetries` | `2` | Extra attempts after transient failures (deterministic failures never retry) |
| `maxEntriesPerKind` | `50` | Facts/decisions/constraints/risks cap per stable |
| `maxEntryBytes` | `4000` | One entry's UTF-8 byte cap |
| `maxListItems` | `40` | One list field's item cap |

### The `task-state-prompt` preset row

`maxBytes` (`8000` in the shipped preset) bounds one rendered snapshot in UTF-8
bytes. The provider and prompt consumer are independent: with the provider
absent, the consumer renders nothing and the preset still mounts.

### The compaction preset rows

The `contextual` preset replaces the official compaction rows with this
bundle's `compaction-basic` and `tool-result-pruner`, which retain the official
rc.1 configuration vocabulary (`thresholdRatio`, `retainRatio`/`retainTokens`,
`summarizationProvider`/`summarizationModel`, `maxTokens`,
`compactionRetries`, `maxOverflowRetries`, `modelPolicies`, `auto`) plus the
pruner's experimental `hardLimitChars`. `command-compact` stays official.

## Installation

The bundle targets the **web profile** (`dsh --profile web`): the web profile
composes the `agent-presets` roster row that makes the shipped `contextual`
preset selectable and the default.

```sh
# Install a pinned, immutable tag:
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.1'
# Then restart the profile:
dsh --profile web
```

> `<owner>` is a placeholder: this repository has not published a GitHub
> release yet, so the install command above is a template, not a live URL.
> Nothing here has been published. `package.json` deliberately carries no
> `repository.url`.

After startup, new web sessions compose the **contextual** preset by default:
full `standard`-level capabilities plus the task-state snapshot and the
region-aware compaction backend. The session header shows **Context enhancement · 4**;
opening it lists durable task state, task-state injection, tool-result pruning, and
region-aware compaction separately. Each row reports its loaded state and the
current Session's trigger count from Session projections and trajectory events.
`standard`, `minimal`, `ptc`, and `cordis` remain selectable, and presets you
author under `$DSH_HOME/.agent-presets` remain discoverable.

## Verify the header panel

1. Start the web profile and open a new `contextual` session.
2. Click **Context enhancement · 4** beside the session title.
3. Confirm that the panel has four independently named rows; a new session starts at `Loaded / No record yet`.
4. Send a normal message and reopen the panel; request trajectory records advance the task-state rows.
5. Generate enough tool activity to prune results, or run compaction; the matching rows show `Triggered N times`.
6. Open the `Trajectory` view and inspect `compaction/prune`, `compaction/start`, and `compaction/end` as the raw evidence for pruning and compaction.

Run the package and isolated-install gates directly:

```sh
pnpm test
pnpm typecheck
pnpm build
pnpm run release:check
node scripts/verify-profile-install.mjs .\\dsh-context-enhancement-0.1.1.tgz
```

## Behavior on a fresh profile / no agent-presets row

- **Fresh web profile.** `dsh plugin add` creates the profile if needed, adds
  the bundle to `dsh.profile.bundles`, and (on restart) applies this bundle's
  patch: the host `task-state-basic` row mounts, and `agent-presets` points
  its default at `contextual`.
- **Profile without an `agent-presets` row** (for example a custom profile or
  a headless-style composition that mounts no roster): the bundle's
  `agent-presets` patch is skipped with a loader warning, and only the host
  `task-state-basic` insertion applies. The provider still works for sessions
  on that profile; no preset default is changed because there is no roster to
  change.

## Upgrade, rollback, uninstall

Profile plugin membership is frozen for the lifetime of a running profile —
restart after any change.

```sh
# Upgrade to a newer tag (rewrite the spec explicitly to avoid drift):
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.1'
# Roll back to the previous tag:
dsh plugin --profile web add 'github:<owner>/dsh-context-enhancement#v0.1.1'
# Uninstall:
dsh plugin --profile web remove dsh-context-enhancement
```

After each change, restart the profile. Uninstalling:

- removes the bundle layer (`dsh-context-enhancement` leaves
  `dsh.profile.bundles`), so the host `task-state-basic` row and the
  `agent-presets` default override disappear on the next start;
- leaves the **storage untouched**: committed task-state records, the audit
  table, and ordinary Session logs are retained. The provider simply stops
  publishing `ctx.taskState`;
- restores the official composition: because the patch never disables an
  official host row, `standard`'s official compaction rows return unchanged.

## Storage: retention and cleanup

All durable state lives under the DSH home:

- Task state: `$DSH_HOME/storages/context_enhancement_task_state.json`
  (single-layout storage-domain unit with `sessions` and `audit` tables). The
  domain name is deliberately `context_enhancement_task_state` so it never
  collides with a differently-formatted upstream domain.
- Sessions: unchanged (`$DSH_HOME/sessions`).

The provider **never deletes** its medium. If you want to remove task-state
records, stop the profile and delete that domain file; the provider treats a
genuinely absent domain as first-time state. A damaged or incompatible domain
is left unchanged: the provider disables loudly and ordinary Sessions continue.

## Requirements

- Node `^22.19.0 || >=24.0.0`
- pnpm `11.7.0` (repository `packageManager`)
- A DSH v0.1.2-rc.1 deployment compatible with the exact peer pins
  (`@deepseek-ai/dsh-*` at `0.1.2-rc.1`, `@deepseek-ai/cordis` at `4.0.2`,
  `@deepseek-ai/schemastery` at `3.18.2`). The Bundle also declares the same
  rc.1 packages as runtime dependencies so a GitHub install carries the loader
  dependency closure; `zod@4.4.3` is bundled as a normal dependency.

## Repository commands

```sh
pnpm install          # install the dev toolchain (allowlist in pnpm-workspace.yaml)
pnpm run build        # tsc src -> lib/types, then tsdown -> lib/*.js per entry
pnpm run typecheck    # strict typecheck of src and tests
pnpm run test         # vitest run
pnpm run release:check   # mechanical pre-tag checks (deps, exports, pack contents)
```

No `prepare`/`postinstall` scripts exist, and none are planned: release tags
commit built artifacts (`lib/` is committed), so a GitHub install never runs a
build script.

## Compatibility with rc.1

- Pinned to DeepSeek Harness **v0.1.2-rc.1**. Upgrading DSH requires a new
  bundle tag after re-verification; peers are never widened speculatively.
- The published rc.1 `@deepseek-ai/dsh-compaction` package does **not** export
  the Card5/6 leaves (`toolSegments`, `selection-guard`); those are copied
  under `src/internal/` with provenance. No `@deepseek-ai/dsh-*` `src/*`
  subpath is imported at runtime.
- rc.1's `GenerateOptions.purpose` is a closed `'compaction' | 'session-title'`
  union; the task-state auxiliary call types its own purpose and casts once at
  the stream boundary.
- The task-state audit is a storage-domain audit table rather than Session
  events (see Transparency). rc.1 `task-state/*` Session events are never
  written.

## Layout

```text
package.json            root package + dsh.bundle.patch manifest
cordis.patch.yml        bundle patch (host task-state-basic + web agent-presets)
src/                    TypeScript sources (entry modules + internal ports)
  task-state.ts           contract: Service Definition + durable schemas + audit
  task-state-basic.ts     durable provider (domain, worker, validation)
  task-state-prompt.ts    systemPrompt consumer
  compaction-basic.ts     region-aware compaction replacement
  tool-result-pruner.ts   region-aware pruning service
lib/                    committed built runtime (tsc types + tsdown entries)
presets/contextual/     shipped agent preset (copy of rc.1 standard + deltas)
tests/                  vitest specs (unit, real composition, keyless scenarios)
scripts/release-check.mjs   pre-tag mechanical gate
CHANGELOG.md            changes, unreleased 0.1.1
THIRD_PARTY_NOTICES.md  DSH MIT source attribution
README.md / README.zh.md
```

## License

MIT. Portions are adapted from DeepSeek Harness (MIT) — see
`THIRD_PARTY_NOTICES.md`.
