/** Context-enhancement header panel dictionaries. */
export declare const NS = "contextEnhancement";
export declare const zh: {
    readonly trigger: "上下文增强 · 4项";
    readonly panelLabel: "上下文增强效果";
    readonly loaded: "已装载";
    readonly evidence: "触发 {count} 次";
    readonly waiting: "尚无记录";
    readonly taskStateBasic: "持久任务状态";
    readonly taskStateBasicDetail: "sessions / audit 持久记录";
    readonly taskStatePrompt: "任务状态注入";
    readonly taskStatePromptDetail: "请求系统提示中的 task-state 快照";
    readonly toolResultPruner: "工具结果裁剪";
    readonly toolResultPrunerDetail: "轨迹中的 compaction/prune 记录";
    readonly compactionBasic: "区域感知压缩";
    readonly compactionBasicDetail: "轨迹中的 compaction/start 与 compaction/end";
    readonly footer: "触发后的证据会出现在当前会话的轨迹中。";
};
export declare const en: Record<ContextEnhancementKey, string>;
export type ContextEnhancementKey = keyof typeof zh;
//# sourceMappingURL=locales.d.ts.map